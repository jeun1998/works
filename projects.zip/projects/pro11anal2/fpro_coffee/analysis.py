from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import koreanize_matplotlib
import matplotlib
matplotlib.use("Agg")
import scipy.stats as stats

BRAND_ORDER = ["스타벅스","폴바셋","이디야","탐앤탐스"]

def analysis_func(rdata:list[dict]):
    df = pd.DataFrame(rdata)

    if df.empty:
        return pd.DataFrame(), "데이터가 없어요", pd.DataFrame()

    df = df.dropna(subset=["gender","co_survey"])

    crosstab = pd.crosstab(index=df["gender"], columns=df["co_survey"])

    if crosstab.size == 0 or crosstab.shape[0] < 2 or crosstab.shape[1] < 2:
        return crosstab, "표본자료가 부족해서 카이제곱 검정 수행 불가~~", df

    alpha = 0.05
    chi2, pv, dof, expected = stats.chi2_contingency(crosstab)

    min_expected = expected.min()
    note = ""
    if min_expected < 5:
        note = f"<br><small>*주의 : 기대빈도 최소값 {min_expected:2f} (5미만)</small>"
    if pv >= alpha:
        results = f"p값 {pv:.7f} >= {alpha} : 성별에 따른 커피 선호 브랜드의 <b>차이가 없다(귀무가설 채택)</b> {note}"
    else:
        results = f"p값 {pv:.7f} >= {alpha} : 성별에 따른 커피 선호 브랜드의 <b>차이가 있다(대립가설 채택)</b> {note}"

    return crosstab, results, df

def save_barchart_func(df:pd.DataFrame, out_path:Path) -> bool:
    if df is None or df.empty or "co_survey" not in df.columns:
        return False

    counts = df["co_survey"].value_counts().reindex(BRAND_ORDER, fill_value=0)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    fig = plt.figure()
    ax = counts.plot(kind="bar", width=0.6, edgecolor="black")
    ax.set_xlabel("커피 브랜드명")
    ax.set_ylabel("선호 건수")
    ax.set_title("커피 브랜드별 선호 건수")
    ax.set_xticklabels(BRAND_ORDER, rotation=0)
    fig.tight_layout()
    fig.savefig(str(out_path), dpi=120, bbox_inches="tight")
    plt.close(fig)

    return True