# flask app의 entry point
# 라우팅, 서버 실행 담당
# jinja2 : flask에서 html을 동작으로 렌더링할 때 사용하는 템플릿 엕진.
# 왜 서버에서 html 문을 완성한 후 클라이언트 전송.
# html 안에 파이썬 변수를 넣고, 반복/조건문 등을 사용할 수 있게 해주는 도구
# reader_template : html 템플릿 파일(jinja2 템플릿)을 읽어 필요한 값을
# 채운 후 완성된 html을 응답으로 반환해 주는 함수

from flask import Flask, render_template
app = Flask(__name__);

@app.route("/")
def home():
    return render_template("home.html")
@app.route("/hello")
def hello():
    name = "길동이"
    addr = "서초구 서초2동 123"
    return render_template("hello.heml", name=name, juso=addr);
@app.route("/world")
def world_image():
    return render_template("my.html")
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000);