# xg boost: boosting 알고리즘을 구현한 분류/예측 모델
# boosting은 약한 분류기에 대해 샘플의 일부를 보완해가며
# 순차적으로 학습해 강한 분류기를 만듦

# brest_cancer dataset

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import koreanize_matplotlib
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import xgboost as xgb
from lightgbm import LGBMClassifier
import lightgbm as lgb
pd.set_option('display.max_columns', None)

data = load_breast_cancer()
print(data.feature_names)
x = pd.DataFrame(data.data, columns=data.feature_names)
y = data.target
print(x[:2], x.shape)
print(y[:2])

print('레이블 분포 : ', \
    {name:(y == i).sum() for i, name in enumerate(data.target_names)}
    )

x_train, x_test, y_train, y_test = train_test_split(
    x, y, test_size=0.2, random_state=12, stratify=y
)
print(x_train.shape, x_test.shape, y_train.shape, y_test.shape)

xgb_clf = xgb.XGBClassifier(
    booster='gbtree',
    max_depth=6,
    n_estimator=200,
    eval_metric = 'logloss',
    random_state = 42
)
xgb_clf.fit(x_train, y_train)

lgb_clf = LGBMClassifier(
    n_estimators=200, random_state=42, verbose = -1
)
lgb_clf.fit(x_train, y_train)

pred_xgb = xgb_clf.predict(x_test)
pred_lgb = lgb_clf.predict(x_test)
print(f'XGBClassifier acc : {accuracy_score(y_test, pred_xgb):.5f}')
print(f'LGVMClassifier acc : {accuracy_score(y_test, pred_lgb):.5f}')
print()

booster = xgb_clf.get_booster()
xgb_gain = pd.Series(booster.get_score(importance_type='gain'))
lgb_gain = pd.Series(
    lgb_clf.booster_.feature_importance(importance_type='gain'),
    index=x_train.columns
)

xgb_gain_pct = 100 * xgb_gain / (xgb_gain.sum() if xgb_gain.sum() != 0 else 1)
lgb_gain_pct = 100 * lgb_gain / (lgb_gain.sum() if lgb_gain.sum() != 0 else 1)
# print(xgb_gain_pct)
# print(lgb_gain_pct)

xgb_gain_pct = xgb_gain_pct.reindex(x_train.columns).fillna(0)
lgb_gain_pct = lgb_gain_pct.reindex(x_train.columns).fillna(0)

comp_df = pd.DataFrame({
    'XGBoost(gain %)':xgb_gain_pct,
    'LightGBM(gain %)':lgb_gain_pct
}).sort_values('XGBoost(gain %)', ascending=False)
print(comp_df.head(10))

topk = 5
top = comp_df.head(topk)[::-1]
fig, axes = plt.subplots(1, 2, figsize=(8, 5))
xmax = float(np.ceil(top.max().max()))

for ax, col in zip(axes, ['XGBoost(gain %)','LightGBM(gain %)']):
    ax.barh(top.index, top[col])
    ax.set_title(f'{col.split()[0]} Feature importance')
    ax.set_xlabel('importance (%)')
    ax.set_xlim(0, xmax)

plt.tight_layout()
plt.show()